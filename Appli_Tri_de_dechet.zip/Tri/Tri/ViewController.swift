//
//  ViewController.swift
//  Tri
//
//  Created by Finaritra Randriamitandrina on 05/03/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

